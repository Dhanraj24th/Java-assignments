package Banks;
import static Banks.PopulatedList.Populatedlist;
import static Banks.ValidationRulesBank.*;

import java.util.Map;
import java.util.Scanner;

public class BankTester {

	public static void main(String[] args) throws BankException {
		// TODO Auto-generated method stub
 
        System.out.println("");		
		try (Scanner sc=new Scanner(System.in)){
		  Map <Integer,MyBankAccount> Bankdetails=Populatedlist();
           boolean exit=false;			
			
			while(!exit) {
				System.out
				.println("Options 1. Create A/C 2. Display all accounts 3. Transfer Funds " 
		+ "4.Close A/c 5. Fetch A/c Summary 6.Freeze A/cs 0.Exit");
				try {
					switch(sc.nextInt()) {
//					
//					accountDetailsAccept(int acctNo, String name, String type,double balance,String createdon, 
//							Map<Integer,MyBankAccount> details
					case 1 : 
						MyBankAccount account=accountDetailsAccept(sc.nextInt(),sc.next(),sc.next(),sc.nextDouble(),sc.next() ,Bankdetails);		
				   
				        Bankdetails.put(account.getAcctNo(), account);
				        System.out.println("New Account Created");
						
						break;
					case 2 :
						for(MyBankAccount a :Bankdetails.values()) {
						System.out.println(a);
						}
						break;
					case 3 :
					     System.out.println("Enter source accountNo \n destination AccountNO \n transfer amount");
					               Bankdetails.get(sc.nextInt()).transferFunds(Bankdetails.get(sc.nextInt()),sc.nextDouble());
					                
					     
					     break;
					case 4:
						System.out.println("Enter Account");
						break;
					
					case 5:
						System.out.println("Enter account no ");
						MyBankAccount a=Bankdetails.get(sc.next());
						if(a!=null) {
						  throw new  BankException("Enter account is invalid");
						}
					    System.out.println(a);
					case 6:
						
						for(MyBankAccount my: Bankdetails.values()) {
							if(my.getType()==AcctType.SAVING) {
								my.setIsActive(false);
							}
						}
						break;
					}
				
					
					
					
					
					
					
					
				}catch(Exception e) {
					
					System.out.println(e.getMessage());
				}
				
				
		
				
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
		}
		
		
		
	}

}
