package Banks;

import static Banks.ValidationRulesBank.ValidateAmount;
import java.time.LocalDate;

public class MyBankAccount {

	private int acctNo;
	private double balance;
	private LocalDate createdon;
	private String name;
	private Boolean isActive;
	private LocalDate lastUpdated;
	private AcctType type;
	public MyBankAccount(int acctNo, double balance, LocalDate createdon, String name,
			AcctType type) {
		super();
		this.acctNo = acctNo;
		this.balance = balance;
		this.name = name;
		this.isActive = true;
		this.lastUpdated = createdon;
		this.type = type;
		this.createdon=createdon;
	}
	public int getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(int acctNo) {
		this.acctNo = acctNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public LocalDate getCreatedon() {
		return createdon;
	}
	public void setCreatedon(LocalDate createdon) {
		this.createdon = createdon;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public LocalDate getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(LocalDate lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public AcctType getType() {
		return type;
	}
	public void setType(AcctType type) {
		this.type = type;
	}
	public void transferFunds(MyBankAccount dest,double amount) throws BankException {
	ValidateAmount(this.balance-amount );
	this.withdraw(amount);
	dest.Deposite(amount,this);
	
	}
	@Override
	public String toString() {
		return "MyBankAccount [acctNo=" + acctNo + ", balance=" + balance + ", createdon=" + createdon + ", name="
				+ name + ", isActive=" + isActive + ", lastUpdated=" + lastUpdated + ", type=" + type + "]";
	}
	public void withdraw(double amount) throws BankException {
	if(this.isActive)
		this.balance-=amount;
	else {
		   throw new BankException ("Account  Deactivated !!");
	}
	System.out.println("Amount withdrawd ");
	}
	public void Deposite( double amount,MyBankAccount source) throws BankException {
	 if(this.isActive)
		this.balance+=amount;
	 else {
		 source.balance+=amount;
	      throw new BankException ("transction Faild !!");
	 }
	  
	}
	
	
}
