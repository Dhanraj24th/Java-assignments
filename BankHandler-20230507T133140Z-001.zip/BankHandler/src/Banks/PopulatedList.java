package Banks;

import static Banks.ValidationRulesBank.*;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class PopulatedList {
//	int acctNo, double balance, LocalDate createdon, String name,
//	LocalDate lastUpdated, AcctType type) {
	public static Map <Integer,MyBankAccount> Populatedlist() throws BankException{
		// TODO Auto-generated method stub
        Map<Integer,MyBankAccount> maplist=new HashMap<>();
		
        System.out.println("put "+maplist.put(101, accountDetailsAccept(101,"Rama Kher","saving",12000,"2023-01-01", maplist)));
		System.out.println("put "+maplist.put(10, accountDetailsAccept(10,"Kiran Shekh","current",8000,"2023-02-11",maplist)));
		System.out.println("put "+maplist.put(50, accountDetailsAccept(50,"Shubham Agarwal","saving",14000,"2023-05-21",maplist)));
		System.out.println("put "+maplist.put(35, accountDetailsAccept(35,"Kunal Singh","fd",120000,"2022-11-01",maplist)));
		System.out.println("put "+maplist.put(48, accountDetailsAccept(48,"Rekha Patil","saving",111000,"2022-12-11",maplist)));
		System.out.println("put "+maplist.put(65, accountDetailsAccept(65,"Mihir Rao","saving",18000,"2023-05-01",maplist)));
		System.out.println("put "+maplist.put(90, accountDetailsAccept(90,"Shirish Inamdar","FD",80000,"2023-12-11",maplist)));
		return maplist;
        

		
	}

}
