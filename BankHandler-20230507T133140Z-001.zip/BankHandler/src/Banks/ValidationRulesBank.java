package Banks;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class ValidationRulesBank {
	
	public static final int MIN_BALANCE=6000;

	
	public static MyBankAccount accountDetailsAccept(int acctNo, String name, String type,double balance,String createdon, 
		Map<Integer,MyBankAccount> details) throws BankException{
		ValidateDupAcc(acctNo,details );
         ValidateAmount(balance); 	
        LocalDate credate= valiLocalDate(createdon);
          //    LocalDate LastDate= valiLocalDate(lastUpdated);
       AcctType actype=  ValidateAccountType(type);
//       int acctNo, double balance, LocalDate createdon, String name,
//		AcctType type
       System.out.println("data comes in accontdetails");
		return new MyBankAccount(acctNo,balance,credate,name,actype);
	
	}
	public static void ValidateDupAcc(int accono,Map <Integer,MyBankAccount> BankList) throws BankException {
		if(BankList.containsKey(accono))
			throw new BankException("Dup account details");
		
	}
	
	public static double ValidateAmount(double amount) throws BankException {
		if(amount<MIN_BALANCE)
			throw new BankException("Amount is below Min required");
		System.out.println("amount checked");
		return amount;
	}
	public  static LocalDate valiLocalDate(String createdDate) {
		return LocalDate.parse(createdDate);
	}
	public  static AcctType ValidateAccountType(String type) {
	      return  AcctType.valueOf(type.toUpperCase());
	}
//	public static void checkAccountmin(double amount,Map<Integer,MyBankAccount> aclist) throws BankException {
//	      ValidateAmount( aclist.get(accountno).getBalance());
//	}
//	
	
	
}
