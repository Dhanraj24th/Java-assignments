package Banks;


public enum AcctType {
	
SAVING,CURRENT,FD,DMAT,LOAN


}
