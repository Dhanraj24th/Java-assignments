import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class SerializationClass {

	public static void serialization(String fname,List<VehicleClass> list) throws IOException {
		
		try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(fname))) {
	       out.writeObject(list);	
			}
	}
}
