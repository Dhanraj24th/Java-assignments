
public enum Color {

WHITE(5000),BLACK(6000),RED(8000),SILVER(9000);
   private	double price; 
	private Color(double spPrice) 
	{
	   this.price=spPrice;		
	}
	public void setprice(double setPrice) {
	this.price=setPrice;	
	}
	public double getprice() {
		return this.price;
	}
	@Override
	public String toString () 
	{
	return this.name()+this.price;	
	}
	
}
