
public class VehicleException extends Exception{

     VehicleException(String msg){
    	super(msg);    
     }		
}
