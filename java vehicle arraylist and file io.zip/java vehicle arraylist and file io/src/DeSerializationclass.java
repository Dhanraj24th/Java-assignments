import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

public class DeSerializationclass {

	public static ArrayList<VehicleClass> DeSerialization(String name,List<VehicleClass> vehilist ) throws FileNotFoundException, IOException, ClassNotFoundException{
		
		try(ObjectInputStream in=new ObjectInputStream(new FileInputStream(name))){
			
		
			return (ArrayList<VehicleClass>) in.readObject();
			
		} 
		
				
	}
	
	
}
