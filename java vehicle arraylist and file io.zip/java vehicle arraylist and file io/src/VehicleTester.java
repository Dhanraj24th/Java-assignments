import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;
public class VehicleTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	try(Scanner sc=new Scanner(System.in)){
		
    List<VehicleClass> vehicleList=ShowroomUtils.populateShowroom(); 		
   List<VehicleClass> vehicleList1;
   System.out.println("Enter file name");
  vehicleList=DeSerializationclass.DeSerialization(sc.next(), vehicleList);
    boolean exit=false;	//String chesisNO, String name, Color cname, LocalDate manfacturingDate, String companyName
	
    while(!exit) {
    	System.out.println("Enter 1. Accept Vehicle Details");
    	System.out.println("Enter 2. Display Vehicle Details");
    	System.out.println("Enter 3. Display Vehicle Details");
    	System.out.println("Enter 4. sortbyvehicle color");
    	try {
    	switch(sc.nextInt()){
    		
    		case 1:
			VehicleClass obj=ValidationVehicleRules.VehicleAcceptDetails(sc.next(),sc.next(),sc.nextDouble(),sc.next(),sc.next(),vehicleList);
			vehicleList.add(obj);		
    			break;
    		case 2:
    		   vehicleList.forEach(p -> System.out.println(p));
    			
    			break;
    		
    		case 3:
    		     Collections.sort(vehicleList);
    			break;
    		
    		case 4:	
    			System.out.println("Enter Chesis no want to delete");
    			ValidationVehicleRules.DeleteRecordByChesis(sc.next(),vehicleList);
    			break;
    		case 5:
    			//System.out.println("");	
    		     vehicleList.stream().filter(p -> p.getCompanyName().contains(sc.next())).map(p -> p.getChesisNO()).forEach(p -> System.out.println(p));;  	    
    			break;
    		case 6:
    			
    			exit=true;
    			
       	 }
    	} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   	
       }
    System.out.println("enter file name");
    SerializationClass.serialization(sc.next(),vehicleList);
	 } catch (Exception e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	
   }
	
}
