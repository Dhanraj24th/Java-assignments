import java.time.LocalDate;
import java.time.Period;
import java.util.List;

public class ValidationVehicleRules {
//"abc-1234", "red", 345678, "2023-02-14", "Honda", vehicles
	public static VehicleClass VehicleAcceptDetails( String chesisNO,String cname,double newprice,String manfacturingDate, String companyName,List<VehicleClass> vehiclelist) throws VehicleException
	{
		LocalDate mfdate=DateValidation(manfacturingDate);
		Color Colorname=ColorValidation(cname);
	    newprice+=Colorname.getprice();
	//	String chesisNO, String name, Color cname, LocalDate manfacturingDate, String companyName,		
		return new VehicleClass(chesisNO,Colorname,mfdate,companyName,newprice);

	}
	
	public static Color ColorValidation(String color) 
	{
	         Color name=Color.valueOf(color.toUpperCase());	
		     return name;
	}
	
	public static LocalDate DateValidation(String mfdate) throws VehicleException
	{
     int diff=Period.between(LocalDate.parse(mfdate), LocalDate.now()).getYears();
	 if(diff<2)
     return LocalDate.parse(mfdate); 
     throw new VehicleException("Mgf Date is invalid");
                           	
	}
	public static String chesisvalidation(String chisisno,List<VehicleClass> vlist) throws VehicleException {
	     
		if(vlist.contains(new VehicleClass(chisisno))) {
			throw new VehicleException("Entered Duplicate Chisisno ");
		}
		return chisisno;
		
	}
	public static void DeleteRecordByChesis(String chesis,List<VehicleClass> list) throws VehicleException {
	int index=list.indexOf(new VehicleClass(chesis));	
		if(index==-1) {
			throw new VehicleException("Chesis no invalid");
		}
		else {
			list.remove(index);
			System.out.println("Entry Removed");
		}
	}	
	
}
