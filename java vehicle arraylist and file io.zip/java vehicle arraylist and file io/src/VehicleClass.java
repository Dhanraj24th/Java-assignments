import java.io.Serializable;
import java.time.LocalDate;
public class VehicleClass implements Comparable<VehicleClass>,Serializable {
private	String ChesisNO;

 //newtprice manfudate companuy name isavailable
private	Color cname;
private	LocalDate manfacturingDate;
private	String companyName;
private	boolean isAvailable;
private  double price;
	
	
	public VehicleClass(String chesisNO, Color cname, LocalDate manfacturingDate, String companyName,double newprice) {
		super();
		this.price=newprice;
		ChesisNO = chesisNO;
		
		this.cname = cname;
		this.manfacturingDate = manfacturingDate;
		this.companyName = companyName;
		//this.isAvailable = isAvailable;

		
	}
	@Override
	public String toString() {
		return "VehicleClass [ChesisNO=" + ChesisNO  + ", cname=" + cname + ", manfacturingDate="
				+ manfacturingDate + ", companyName=" + companyName + ", isAvailable=" + isAvailable + "]";
	}
	
	public VehicleClass(String chesis) {
		this.ChesisNO=chesis;
	}	
	
	@Override
	public boolean equals(Object o)
	{  
		if(o instanceof VehicleClass) 
		{
			return this.ChesisNO.equals(((VehicleClass)o).ChesisNO);    
		}
		return false;
			
	}
	
	public String getChesisNO() {
		return ChesisNO;
	}


	public void setChesisNO(String chesisNO) {
		ChesisNO = chesisNO;
	}

	public Color getCname() {
		return cname;
	
	}
	public void setCname(Color cname) {
		this.cname = cname;
	}

	public LocalDate getManfacturingDate() {
		return manfacturingDate;
	}

	public void setManfacturingDate(LocalDate manfacturingDate) {
		this.manfacturingDate = manfacturingDate;
	}
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public boolean isAvailable() {
		return isAvailable;
	}
	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	@Override
	public int compareTo(VehicleClass o) {
		return this.ChesisNO.compareTo(o.ChesisNO);
		// TODO Auto-generated method stub	
	}
	
}

