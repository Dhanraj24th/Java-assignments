import java.util.ArrayList;
import java.util.List;

public class ShowroomUtils {
//Add a static method to return populated list(sample hardcoded data) of vehicles
	public static List<VehicleClass> populateShowroom() {
		try {
			ArrayList<VehicleClass> vehicles = new ArrayList<>();
			//String chesisNO, String name, String cname,String manfacturingDate, String companyName,double newprice,List<VehicleClass> vehicl
			vehicles.add(ValidationVehicleRules.VehicleAcceptDetails("abc-1234", "red", 345678, "2023-02-14", "Honda", vehicles));
			vehicles.add(ValidationVehicleRules.VehicleAcceptDetails("abc-1230", "white", 445678, "2023-03-14", "Honda", vehicles));
			vehicles.add(ValidationVehicleRules.VehicleAcceptDetails("abc-1233", "white", 375678, "2023-02-18", "Honda", vehicles));
			vehicles.add(ValidationVehicleRules.VehicleAcceptDetails("abc-1238", "red", 315678, "2023-03-01", "Maruti", vehicles));
			vehicles.add(ValidationVehicleRules.VehicleAcceptDetails("abc-1239", "white", 395678, "2023-02-24", "Honda", vehicles));
			vehicles.add(ValidationVehicleRules.VehicleAcceptDetails("abc-1231", "white", 345878, "2023-03-15", "Maruti", vehicles));
			vehicles.add(ValidationVehicleRules.VehicleAcceptDetails("abc-1232", "red", 385678, "2023-03-25", "Honda", vehicles));
			vehicles.add(ValidationVehicleRules.VehicleAcceptDetails("abc-1240", "black", 305678, "2023-03-01", "Maruti", vehicles));
			return vehicles;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}
}
